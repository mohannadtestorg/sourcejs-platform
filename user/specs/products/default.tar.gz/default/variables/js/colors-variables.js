UX.variables = {
}